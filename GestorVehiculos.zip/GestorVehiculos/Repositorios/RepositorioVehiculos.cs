﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;

namespace GestorVehiculos.Repositorios
{
    internal class RepositorioVehiculos
    {
        private SqliteConnection conexion;

        public RepositorioVehiculos(SqliteConnection conexion)
        {
            this.conexion = conexion;

            using var comando = conexion.CreateCommand();
            comando.CommandText = @"
                CREATE TABLE IF NOT EXISTS vehiculos (
                    id INTEGER PRIMARY KEY,
                    marca TEXT NOT NULL,
                    modelo TEXT NOT NULL,
                    anio INTEGER NOT NULL,
                    ultima_revision TEXT NOT NULL,
                    tiene_seguro INTEGER NOT NULL,
                    kilometraje INTEGER NOT NULL
                );
            ";
            comando.ExecuteNonQuery();
        }

        public List<Vehiculo> Listar()
        {
            var lista = new List<Vehiculo>();

            using var cmd = conexion.CreateCommand();
            cmd.CommandText = "SELECT * FROM vehiculos ORDER BY id DESC;";

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var vehiculo = new Vehiculo(
                    id: (long)reader["id"],
                    marca: reader["marca"].ToString(),
                    modelo: reader["modelo"].ToString(),
                    anio: Convert.ToInt32(reader["anio"]),
                    ultimaRevision: DateTime.Parse(reader["ultima_revision"].ToString()),
                    tieneSeguro: Convert.ToInt32(reader["tiene_seguro"]) == 1,
                    kilometraje: Convert.ToInt32(reader["kilometraje"])
                );
                lista.Add(vehiculo);
            }

            return lista;
        }

        public void Crear(Vehiculo v)
        {
            using var cmd = conexion.CreateCommand();
            cmd.CommandText = @"
                INSERT INTO vehiculos (marca, modelo, anio, ultima_revision, tiene_seguro, kilometraje)
                VALUES (@marca, @modelo, @anio, @revision, @seguro, @km);
            ";
            cmd.Parameters.AddWithValue("@marca", v.Marca);
            cmd.Parameters.AddWithValue("@modelo", v.Modelo);
            cmd.Parameters.AddWithValue("@anio", v.Anio);
            cmd.Parameters.AddWithValue("@revision", v.UltimaRevision.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@seguro", v.TieneSeguro ? 1 : 0);
            cmd.Parameters.AddWithValue("@km", v.Kilometraje);
            cmd.ExecuteNonQuery();

            using var idCmd = conexion.CreateCommand();
            idCmd.CommandText = "SELECT last_insert_rowid();";
            v.Id = (long)idCmd.ExecuteScalar();
        }

        public void Actualizar(Vehiculo v)
        {
            using var cmd = conexion.CreateCommand();
            cmd.CommandText = @"
                UPDATE vehiculos SET
                    marca = @marca,
                    modelo = @modelo,
                    anio = @anio,
                    ultima_revision = @revision,
                    tiene_seguro = @seguro,
                    kilometraje = @km
                WHERE id = @id;
            ";
            cmd.Parameters.AddWithValue("@id", v.Id);
            cmd.Parameters.AddWithValue("@marca", v.Marca);
            cmd.Parameters.AddWithValue("@modelo", v.Modelo);
            cmd.Parameters.AddWithValue("@anio", v.Anio);
            cmd.Parameters.AddWithValue("@revision", v.UltimaRevision.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@seguro", v.TieneSeguro ? 1 : 0);
            cmd.Parameters.AddWithValue("@km", v.Kilometraje);
            cmd.ExecuteNonQuery();
        }

        public void Eliminar(Vehiculo v)
        {
            using var cmd = conexion.CreateCommand();
            cmd.CommandText = "DELETE FROM vehiculos WHERE id = @id;";
            cmd.Parameters.AddWithValue("@id", v.Id);
            cmd.ExecuteNonQuery();
        }
    }
}
